# An AAA weekend project by Jani & Zsombor

Project to identify who are the winners of public procurement in Hungary.

Uses the K-monitor & CEU Microdata organisations's data and some personal data, so these are not available on github.

[src].


[src]: https://github.com/janosbiro

